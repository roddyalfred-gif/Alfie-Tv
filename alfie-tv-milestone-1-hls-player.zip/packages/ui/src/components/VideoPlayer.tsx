import React, { useEffect, useMemo, useRef, useState } from 'react';
import Hls from 'hls.js';
import { StreamQuality, StreamingEngine } from '@alfie-tv/core';
import type { StreamConfig } from '@alfie-tv/core';

interface VideoPlayerProps {
  streamConfig: StreamConfig;
  onError?: (error: Error) => void;
  onReady?: () => void;
  className?: string;
}

type PlayerStatus =
  | 'Loading stream'
  | 'Ready'
  | 'Playing'
  | 'Paused'
  | 'Buffering'
  | 'Playback error'
  | 'HLS unsupported';

interface QualityOption {
  label: string;
  level: number;
}

const qualityHeight: Record<StreamQuality, number> = {
  [StreamQuality.LOW]: 360,
  [StreamQuality.SD]: 480,
  [StreamQuality.HD]: 720,
  [StreamQuality.FULL_HD]: 1080,
  [StreamQuality.ULTRA_HD]: 2160,
  [StreamQuality.FULL_4K]: 4320,
};

export const VideoPlayer: React.FC<VideoPlayerProps> = ({
  streamConfig,
  onError,
  onReady,
  className = '',
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const engineRef = useRef<StreamingEngine | null>(null);
  const retryCountRef = useRef(0);

  const [engine, setEngine] = useState<StreamingEngine | null>(null);
  const [status, setStatus] = useState<PlayerStatus>('Loading stream');
  const [isPlaying, setIsPlaying] = useState(false);
  const [quality, setQuality] = useState<StreamQuality>(streamConfig.quality);
  const [qualityOptions, setQualityOptions] = useState<QualityOption[]>([]);
  const [errorMessage, setErrorMessage] = useState('');

  const isHls = streamConfig.format === 'hls';

  const nativeHlsSupported = useMemo(() => {
    const video = videoRef.current;
    return Boolean(
      video?.canPlayType('application/vnd.apple.mpegurl'),
    );
  }, []);

  useEffect(() => {
    let cancelled = false;
    const video = videoRef.current;

    if (!video) return;

    const streamingEngine = new StreamingEngine(streamConfig);
    engineRef.current = streamingEngine;
    setEngine(streamingEngine);
    retryCountRef.current = 0;
    setStatus('Loading stream');
    setErrorMessage('');
    setQuality(streamConfig.quality);
    setQualityOptions([]);

    const onPlay = () => {
      setIsPlaying(true);
      setStatus('Playing');
    };

    const onPause = () => {
      setIsPlaying(false);
      setStatus('Paused');
    };

    const onWaiting = () => setStatus('Buffering');
    const onPlaying = () => {
      setIsPlaying(true);
      setStatus('Playing');
    };

    const onCanPlay = () => {
      if (!cancelled) {
        setStatus('Ready');
        onReady?.();
      }
    };

    const onVideoError = () => {
      if (cancelled) return;
      const mediaError = video.error;
      const message = mediaError?.message || 'The stream could not be played.';
      setStatus('Playback error');
      setErrorMessage(message);
      onError?.(new Error(message));
    };

    video.addEventListener('play', onPlay);
    video.addEventListener('pause', onPause);
    video.addEventListener('waiting', onWaiting);
    video.addEventListener('playing', onPlaying);
    video.addEventListener('canplay', onCanPlay);
    video.addEventListener('error', onVideoError);

    const initialize = async () => {
      try {
        await streamingEngine.initialize();

        if (cancelled) return;

        if (isHls && Hls.isSupported()) {
          const hls = new Hls({
            enableWorker: true,
            lowLatencyMode: true,
            backBufferLength: 90,
          });

          hlsRef.current = hls;

          hls.on(Hls.Events.MANIFEST_PARSED, (_event, data) => {
            if (cancelled) return;

            const options = data.levels
              .map((level, index) => ({
                label: level.height
                  ? `${level.height}p`
                  : `${Math.round(level.bitrate / 1000)} kbps`,
                level: index,
              }))
              .sort((a, b) => {
                const aHeight = data.levels[a.level].height || 0;
                const bHeight = data.levels[b.level].height || 0;
                return aHeight - bHeight;
              });

            setQualityOptions(options);
            setStatus('Ready');
            onReady?.();
          });

          hls.on(Hls.Events.LEVEL_SWITCHED, (_event, data) => {
            const level = hls.levels[data.level];
            if (!level) return;

            const height = level.height || 0;
            const nearest = Object.entries(qualityHeight).reduce(
              (best, [candidate, candidateHeight]) =>
                Math.abs(candidateHeight - height) <
                Math.abs(best.height - height)
                  ? { quality: candidate as StreamQuality, height: candidateHeight }
                  : best,
              {
                quality: StreamQuality.HD,
                height: qualityHeight[StreamQuality.HD],
              },
            );

            setQuality(nearest.quality);
          });

          hls.on(Hls.Events.ERROR, (_event, data) => {
            if (cancelled || !data.fatal) return;

            if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
              setStatus('Buffering');
              hls.startLoad();
              return;
            }

            if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
              hls.recoverMediaError();
              return;
            }

            const error = new Error(data.details || 'Fatal HLS playback error.');
            setStatus('Playback error');
            setErrorMessage(error.message);
            onError?.(error);
          });

          hls.loadSource(streamConfig.url);
          hls.attachMedia(video);
        } else if (isHls && nativeHlsSupported) {
          video.src = streamConfig.url;
          video.load();
        } else if (!isHls) {
          video.src = streamConfig.url;
          video.load();
        } else {
          const error = new Error('This browser does not support HLS playback.');
          setStatus('HLS unsupported');
          setErrorMessage(error.message);
          onError?.(error);
        }
      } catch (error) {
        if (!cancelled) {
          const normalized = error instanceof Error ? error : new Error(String(error));
          setStatus('Playback error');
          setErrorMessage(normalized.message);
          onError?.(normalized);
        }
      }
    };

    initialize();

    return () => {
      cancelled = true;
      video.pause();
      video.removeAttribute('src');
      video.load();

      video.removeEventListener('play', onPlay);
      video.removeEventListener('pause', onPause);
      video.removeEventListener('waiting', onWaiting);
      video.removeEventListener('playing', onPlaying);
      video.removeEventListener('canplay', onCanPlay);
      video.removeEventListener('error', onVideoError);

      hlsRef.current?.destroy();
      hlsRef.current = null;

      streamingEngine.stop();
      engineRef.current = null;
      setEngine(null);
    };
  }, [
    streamConfig.url,
    streamConfig.format,
    streamConfig.quality,
    streamConfig.autoQuality,
    streamConfig.bufferSize,
    streamConfig.timeout,
    streamConfig.retryAttempts,
    nativeHlsSupported,
    onError,
    onReady,
    isHls,
  ]);

  const handlePlayPause = async () => {
    const video = videoRef.current;
    if (!video || !engine) return;

    try {
      if (video.paused) {
        await video.play();
        await engine.play();
      } else {
        video.pause();
        engine.pause();
      }
    } catch (error) {
      const normalized = error instanceof Error ? error : new Error(String(error));
      setStatus('Playback error');
      setErrorMessage(normalized.message);
      onError?.(normalized);
    }
  };

  const handleQualityChange = async (value: string) => {
    const selected = Number(value);
    const hls = hlsRef.current;

    if (!hls || selected < 0) return;

    try {
      hls.currentLevel = selected;
      const level = hls.levels[selected];
      if (level?.height) {
        const matching = Object.entries(qualityHeight).reduce(
          (best, [candidate, height]) =>
            Math.abs(height - level.height!) < Math.abs(best.height - level.height!)
              ? { quality: candidate as StreamQuality, height }
              : best,
          { quality: StreamQuality.HD, height: qualityHeight[StreamQuality.HD] },
        );
        setQuality(matching.quality);
        await engine?.changeQuality(matching.quality);
      }
    } catch (error) {
      const normalized = error instanceof Error ? error : new Error(String(error));
      onError?.(normalized);
    }
  };

  const handleRetry = async () => {
    const video = videoRef.current;
    if (!video) return;

    retryCountRef.current += 1;
    setStatus('Loading stream');
    setErrorMessage('');

    const hls = hlsRef.current;
    if (hls) {
      hls.stopLoad();
      hls.startLoad(-1);
      return;
    }

    video.load();

    try {
      await video.play();
    } catch {
      // Browser autoplay policy may require the user to press Play.
    }
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      void handlePlayPause();
    }
  };

  const maxRetries = streamConfig.retryAttempts ?? 3;

  return (
    <div
      className={`relative w-full bg-black outline-none ${className}`}
      tabIndex={0}
      onKeyDown={handleKeyDown}
      role="application"
      aria-label="Alfie TV video player"
    >
      <video
        ref={videoRef}
        className="block h-full w-full object-contain"
        controls
        playsInline
        preload="auto"
        style={{ aspectRatio: '16 / 9' }}
      />

      <div className="pointer-events-none absolute inset-x-0 bottom-0 p-4">
        <div className="pointer-events-auto flex items-center justify-between rounded-lg bg-black/70 px-3 py-2 text-sm text-white">
          <span>{status}</span>
          <span>{quality}</span>
        </div>

        <div className="pointer-events-auto mt-2 flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={() => void handlePlayPause()}
            className="rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-white"
          >
            {isPlaying ? 'Pause' : 'Play'}
          </button>

          {qualityOptions.length > 0 && (
            <select
              value={
                hlsRef.current?.currentLevel !== undefined
                  ? String(hlsRef.current.currentLevel)
                  : ''
              }
              onChange={(event) => void handleQualityChange(event.target.value)}
              className="rounded bg-gray-800 px-3 py-2 text-white"
              aria-label="Video quality"
            >
              <option value="-1">Auto</option>
              {qualityOptions.map((option) => (
                <option key={option.level} value={option.level}>
                  {option.label}
                </option>
              ))}
            </select>
          )}

          {status === 'Playback error' && retryCountRef.current < maxRetries && (
            <button
              type="button"
              onClick={() => void handleRetry()}
              className="rounded bg-gray-700 px-4 py-2 text-white hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-white"
            >
              Retry
            </button>
          )}
        </div>

        {errorMessage && (
          <div className="pointer-events-auto mt-2 rounded bg-black/80 px-3 py-2 text-xs text-red-200">
            {errorMessage}
          </div>
        )}
      </div>
    </div>
  );
};
