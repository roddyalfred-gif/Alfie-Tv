# Alfie TV — Milestone 1 HLS Player Patch

This patch upgrades the shared React player from a plain `<video>` HLS source to real HLS.js playback when Media Source Extensions are available, with native HLS fallback.

## Changes

- Adds `hls.js` 1.7.1 to `packages/ui/package.json`.
- Uses the HLS manifest directly with HLS.js.
- Detects manifest quality levels.
- Adds manual quality selection and Auto mode.
- Keeps the browser's native video controls.
- Handles fatal network/media errors with recovery.
- Adds buffering/ready/playing/error states.
- Adds keyboard Enter/Space play/pause support for TV-style navigation.
- Keeps the existing `StreamingEngine` interface so the rest of the monorepo remains unchanged.

HLS.js documents `loadSource()` + `attachMedia()` for connecting a manifest to a video element and exposes manual quality-level switching. See the HLS.js documentation for platform support and CORS requirements.

## Important

This is the web/shared-player step. It does **not** turn `packages/tv` into a native Android TV player.

For the production Android TV app, the next step should be a native Media3/ExoPlayer adapter behind the same player interface. That is what will give us robust TV hardware decoding, D-pad behavior, audio tracks, subtitles and 4K playback on Android TV devices.

## Apply

Copy these files into the repository, then run:

```bash
npm install
npm run build --workspace @alfie-tv/ui
```

No GitHub branch or commit is included because the connected GitHub integration currently cannot create the requested branch.
