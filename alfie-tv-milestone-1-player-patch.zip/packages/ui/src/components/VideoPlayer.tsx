import React, { useCallback, useEffect, useRef, useState } from 'react';
import { StreamingEngine, StreamQuality } from '@alfie-tv/core';
import type { StreamConfig } from '@alfie-tv/core';

interface VideoPlayerProps {
  streamConfig: StreamConfig;
  onError?: (error: Error) => void;
  onReady?: () => void;
  className?: string;
  autoPlay?: boolean;
}

type PlayerState = 'loading' | 'ready' | 'playing' | 'paused' | 'buffering' | 'error';

const RETRY_DELAY_MS = 2000;

export const VideoPlayer: React.FC<VideoPlayerProps> = ({
  streamConfig,
  onError,
  onReady,
  className = '',
  autoPlay = false,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const engineRef = useRef<StreamingEngine | null>(null);
  const retryTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const retryCountRef = useRef(0);

  const [quality, setQuality] = useState(streamConfig.quality ?? StreamQuality.HD);
  const [state, setState] = useState<PlayerState>('loading');
  const [errorMessage, setErrorMessage] = useState('');
  const [retryCount, setRetryCount] = useState(0);

  const clearRetry = useCallback(() => {
    if (retryTimerRef.current) {
      clearTimeout(retryTimerRef.current);
      retryTimerRef.current = null;
    }
  }, []);

  const loadStream = useCallback(async () => {
    const video = videoRef.current;
    if (!video) return;

    clearRetry();
    setState('loading');
    setErrorMessage('');

    try {
      video.pause();
      video.removeAttribute('src');
      video.load();

      const engine = new StreamingEngine(streamConfig);
      engineRef.current?.stop();
      engineRef.current = engine;
      await engine.initialize();

      video.src = streamConfig.url;
      video.preload = 'auto';
      video.playsInline = true;
      video.setAttribute('playsinline', '');
      video.setAttribute('webkit-playsinline', '');
      video.load();

      setQuality(streamConfig.quality ?? StreamQuality.HD);
      retryCountRef.current = 0;
      setRetryCount(0);
      setState('ready');
      onReady?.();

      if (autoPlay) {
        await video.play();
      }
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Unable to load stream');
      setState('error');
      setErrorMessage(error.message);
      onError?.(error);
    }
  }, [autoPlay, clearRetry, onError, onReady, streamConfig]);

  useEffect(() => {
    void loadStream();

    return () => {
      clearRetry();
      engineRef.current?.stop();
      engineRef.current = null;

      const video = videoRef.current;
      if (video) {
        video.pause();
        video.removeAttribute('src');
        video.load();
      }
    };
  }, [clearRetry, loadStream]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const onPlay = () => setState('playing');
    const onPause = () => {
      if (!video.ended) setState('paused');
    };
    const onWaiting = () => setState('buffering');
    const onPlaying = () => setState('playing');
    const onCanPlay = () => setState(video.paused ? 'ready' : 'playing');

    const onErrorEvent = () => {
      const mediaError = video.error;
      const message = mediaError?.message || 'The stream could not be played.';
      setErrorMessage(message);
      setState('error');
      onError?.(new Error(message));
    };

    const retry = () => {
      if (retryCountRef.current >= streamConfig.retryAttempts) return;

      retryCountRef.current += 1;
      setRetryCount(retryCountRef.current);
      setState('buffering');

      retryTimerRef.current = setTimeout(() => {
        void loadStream();
      }, RETRY_DELAY_MS);
    };

    video.addEventListener('play', onPlay);
    video.addEventListener('pause', onPause);
    video.addEventListener('waiting', onWaiting);
    video.addEventListener('playing', onPlaying);
    video.addEventListener('canplay', onCanPlay);
    video.addEventListener('error', onErrorEvent);
    video.addEventListener('stalled', retry);
    video.addEventListener('emptied', retry);

    return () => {
      video.removeEventListener('play', onPlay);
      video.removeEventListener('pause', onPause);
      video.removeEventListener('waiting', onWaiting);
      video.removeEventListener('playing', onPlaying);
      video.removeEventListener('canplay', onCanPlay);
      video.removeEventListener('error', onErrorEvent);
      video.removeEventListener('stalled', retry);
      video.removeEventListener('emptied', retry);
    };
  }, [loadStream, onError, streamConfig.retryAttempts]);

  const playPause = async () => {
    const video = videoRef.current;
    if (!video) return;

    try {
      if (video.paused) {
        await video.play();
      } else {
        video.pause();
      }
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Playback failed');
      setErrorMessage(error.message);
      setState('error');
      onError?.(error);
    }
  };

  const changeQuality = async (nextQuality: StreamQuality) => {
    setQuality(nextQuality);
    await engineRef.current?.changeQuality(nextQuality);
  };

  return (
    <div
      className={`relative w-full overflow-hidden bg-black text-white ${className}`}
      tabIndex={0}
      onKeyDown={(event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          void playPause();
        }
      }}
    >
      <video
        ref={videoRef}
        className="block h-full w-full object-contain"
        controls
        playsInline
        preload="auto"
        style={{ aspectRatio: '16 / 9' }}
      />

      <div className="pointer-events-none absolute left-0 right-0 top-0 p-4">
        <div className="inline-flex rounded bg-black/70 px-3 py-2 text-sm">
          {state === 'buffering' && 'Buffering…'}
          {state === 'loading' && 'Loading stream…'}
          {state === 'ready' && 'Ready'}
          {state === 'playing' && 'Playing'}
          {state === 'paused' && 'Paused'}
          {state === 'error' && 'Playback error'}
        </div>
      </div>

      {state === 'error' && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/75 p-6 text-center">
          <div className="max-w-xl">
            <p className="mb-3 text-lg font-semibold">Unable to play this stream</p>
            <p className="mb-4 text-sm text-gray-300">{errorMessage}</p>
            {retryCount < streamConfig.retryAttempts && (
              <button
                type="button"
                className="rounded bg-blue-600 px-5 py-3 font-semibold hover:bg-blue-700"
                onClick={() => {
                  retryCountRef.current = 0;
                  setRetryCount(0);
                  void loadStream();
                }}
              >
                Retry
              </button>
            )}
          </div>
        </div>
      )}

      <div className="absolute bottom-0 left-0 right-0 flex items-center justify-between gap-3 bg-gradient-to-t from-black/90 to-transparent p-4">
        <button
          type="button"
          className="rounded bg-white/15 px-4 py-2 font-semibold hover:bg-white/25"
          onClick={() => void playPause()}
        >
          {state === 'playing' ? 'Pause' : 'Play'}
        </button>

        <label className="flex items-center gap-2 text-sm">
          Quality
          <select
            value={quality}
            onChange={(event) => void changeQuality(event.target.value as StreamQuality)}
            className="rounded bg-gray-900 px-3 py-2"
          >
            {Object.values(StreamQuality).map((value) => (
              <option key={value} value={value}>
                {value}
              </option>
            ))}
          </select>
        </label>
      </div>
    </div>
  );
};
