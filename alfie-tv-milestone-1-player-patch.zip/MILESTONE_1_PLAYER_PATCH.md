# Alfie TV — Milestone 1 Player Patch

This patch improves the existing web player without changing the repository architecture.

## Included

- Real HTMLMediaElement playback state
- Loading/ready/playing/paused/buffering/error states
- Stream retry handling using StreamConfig.retryAttempts
- Manual retry UI
- Proper stream cleanup on unmount/change
- Keyboard/TV-friendly Enter/Space play/pause handling
- Quality state remains connected to StreamingEngine
- Fullscreen-capable native browser controls
- 16:9 TV-oriented presentation

## Important

The current core StreamingEngine quality method is still an orchestration layer; it does not inspect an HLS manifest or switch actual HLS renditions. True adaptive HLS quality selection should be implemented with a media engine appropriate to the target platform.

For Android TV, the production player should ultimately use a native media stack (for example Media3/ExoPlayer) rather than relying on browser HLS behavior.

## Install

Replace:
packages/ui/src/components/VideoPlayer.tsx

Then run your normal workspace install/build/test commands.

This patch is intentionally conservative because the repository currently has a cross-platform architecture and the TV package is still a React shell.
